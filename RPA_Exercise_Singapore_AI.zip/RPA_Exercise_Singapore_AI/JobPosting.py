from robocorp.tasks import task
from RPA.Browser.Selenium import Selenium
from RPA.HTTP import HTTP
from RPA.Excel.Files import Files
from config import *
#import requests
#import time

@task
class Job:
    def __init__(self) -> None:
        self.browser = Selenium()
        self.files = Files()
        self.http=HTTP()

    def open_site_and_download_csv(self):
        self.browser.open_available_browser("https://rpaexercise.aisingapore.org/")
        url=self.browser.get_element_attribute("//span[text()='Download Job List']/ancestor::a", "href")
        self.http.download(url, EXCEL_FILE_PATH)
        #element=self.browser.get_webelement("//span[text()='Download Job List']/ancestor::a")
        #url=element.__getattribute__("href")
        #self.browser.wait_for_condition("return lambda: os.path.exists(EXCEL_FILE_PATH)", timeout=10)
        """start_time = time.time()
        response=requests.get(url)
        with open(EXCEL_FILE_PATH, 'wb') as file:
            file.write(response.content)
        
        while not os.path.exists(file_path):
            if time.time() - start_time > timeout:
                raise TimeoutError(f"File download did not complete within {timeout} seconds.")
            time.sleep(2)"""
        
    
    def login(self):
        #login=self.browser.get_element_attribute("//button[@name='login']", "href")
        #self.browser.go_to(login)
        self.browser.click_element("//span[text()='Start Challenge']")
        self.browser.wait_until_element_is_visible("//input[@id='outlined-search' and @name='username' and @placeholder='Username' and @class='MuiInputBase-input MuiOutlinedInput-input']")
        self.browser.input_text("//input[@id='outlined-search' and @name='username' and @placeholder='Username' and @class='MuiInputBase-input MuiOutlinedInput-input']", "jane007") # Username
        self.browser.input_text("//input[@id='password' and @name='password' and @placeholder='Password' and @type='password' and @class='MuiInputBase-input MuiOutlinedInput-input']", "TheBestHR123") # Password
        self.browser.click_element("//button[@class='MuiButtonBase-root MuiButton-root MuiButton-contained MuiButton-containedPrimary' and @id='login' and @name='login']") # Login button
    
    def fill_job_posting_data(self, job_data):
        job_title, job_desc, department, education_level, start_date, end_date, remote, job_type = job_data
        self.browser.wait_until_element_is_visible("//button[@id='newJobPosting']")  
        self.browser.click_element("//button[@id='newJobPosting']")
        self.browser.wait_until_element_is_visible("//div[@class='MuiDialogTitle-root' and @id='form-dialog-title']/h2[@class='MuiTypography-root MuiTypography-h6']")  
        self.browser.input_text("//*[@id='jobTitle']", job_title)
        self.browser.input_text("//*[@id='jobDescription']", job_desc)
        self.browser.select_from_list_by_value("//select[@id='hiringDepartment']", department)
        self.browser.select_from_list_by_label("//select[@id='educationLevel']", education_level)
        self.browser.input_text("//input[@id='postingStartDate']", start_date)
        self.browser.input_text("//input[@id='postingEndDate']", end_date)
        
        if remote == "Yes":
            self.browser.select_radio_button("//input[@name='remote' and @value='Yes']", "Yes")  
        else:
            self.browser.select_radio_button("//input[@name='remote' and @value='No']", "No")  
        
        job_types=job_type.split('/')
        for types in job_types:
            self.browser.select_checkbox(f"//span[contains(text(), '{types}')]")  
        
        self.browser.click_element("//span[text()='Submit']")
    
    def view_and_process_applicants(self,count):
        for n in count:  
            self.browser.click_element("//span[text()='View Applicant List']")  
            self.process_applicants()
            self.browser.click_element("//span[text()='Back to List']")  
            n+=1

    def process_applicants(self):
        job_education_level = self.browser.get_text("//*[@id='root']/div/div/div[2]/div[2]/div[1]/div[10]/p")
        rows = int(self.browser.get_element_count("//*[@id='root']/div/div/div[2]/div[2]/div[2]/table/tbody/tr"))
        for n in range(1, rows + 1):
            applicant_education_level = self.browser.get_text("//*[@id='root']/div/div/div[2]/div[2]/div[2]/table/tbody/tr[{n}]/td[4]")
            pre_screening_score = int(self.browser.get_text("//*[@id='root']/div/div/div[2]/div[2]/div[2]/table/tbody/tr[{n}]/td[5]"))
            if job_education_level == applicant_education_level and pre_screening_score > 70:
                self.browser.click_element("//*[@id='root']/div/div/div[2]/div[2]/div[2]/table/tbody/tr[{n}]/td[7]/div/div/button[1]")  # Approve button
            else:
                self.browser.click_element("//*[@id='root']/div/div/div[2]/div[2]/div[2]/table/tbody/tr[{n}]/td[7]/div/div/button[2]")  # Reject button
            n+=1

    def loop_fill_from_excel(self):
        """Loop filling all the entries from Excel file"""
        self.files.open_workbook("datatable.xlsx")
        table=self.files.read_worksheet_as_table("datatable", header=True)
        self.files.close_workbook()
        for row in table:
            self.fill_job_posting_data(row)
            self.view_and_process_applicants(row)

    def close_site(self):
        self.browser.close_browser()

