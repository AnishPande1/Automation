from robocorp.tasks import task
from JobPosting import Job
#from config import *

@task
def main():
    job = Job()
    job.open_site_and_download_csv()
    job.login()
    job.loop_fill_from_excel()
    job.close_site()

if __name__ == "__main__":
    main()
